export interface DescriptionsForCharacteristics { 
    characteristicType?: string;
    characteristicValue?: string;
}