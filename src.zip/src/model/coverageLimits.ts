export interface CoverageLimits { 
    limitType?: string;
    limitValue?: number;
    selected?: boolean;
}