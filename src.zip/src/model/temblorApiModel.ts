export interface TemblorApiModel { 
    repairCost?: number;
    damageEstimate?: number;
    outofPocketCost?: number;
    largestEQEventMagnitude?: number;
    liklihoodEQEventMagnitude?: number;
}
