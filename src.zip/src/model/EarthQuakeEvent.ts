export interface EarthQuakeEvent 
{
    earthquakeEventID: number,
    latitude: number,
    longitude: number,
    mag: number,
}