import { RiskData } from './riskData';

export interface RateData {
    otherStructuresLimit?: number;
    personalPropertyLimit?: number;
    lossOfUseLimit?: number;
    lossAssessmentLimit?: number;
    dwellingDeductibleAmount?: number;
    otherStructuresDeductibleAmount?: number;
    personalPropertyDeductibleAmount?: number;
    lossOfUseDeductibleAmount?: number;
    lossAssessmentDeductibleAmount?: number;
    overallDeductible?: number;
    dwellingPremium?: number;
    otherStructuresPremium?: number;
    personalPropertyPremium?: number;
    lossOfUsePremium?: number;
    lossAssessmentPremium?: number;
    policyFee?: number;
    totalPremium?: number;
    effectiveDate?: Date;
    riskData?: RiskData;
}
