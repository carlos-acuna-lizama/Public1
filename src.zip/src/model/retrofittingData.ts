export interface RetrofittingData { 
    boltedToFoundation?: boolean;
    bracedCrippleWallsNoCrippleWalls?: boolean;
}
