import { RetrofittingData } from './retrofittingData';
import { TemblorApiModel } from './temblorApiModel';

export interface RiskData { 
    streetAddress?: string;
    city?: string;
    state?: string;
    zipCode?: string;
    yearBuilt?: number;
    squareFootage?: number;
    numberOfStories?: number;
    structureType?: string;
    structureTypeDescription?: string;
    constructionType?: string;
    constructionTypeDescription?: string;
    foundationType?: string;
    partialCoverageADwellingLimitsFactors?: number;
    retrofitting?: RetrofittingData;
    deductibleFactor?: number;
    lossAssessmentCoverage?: number;
    sharedLossSettlement?: number;
    dwellingLimits?: number;
    otherStructuresLimit?: number;
    peronalPropertyLimit?: number;
    lossOfUseLimit?: number;
    temblorData?: TemblorApiModel;
}
