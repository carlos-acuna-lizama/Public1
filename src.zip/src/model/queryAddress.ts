export class QueryAddress {
    streetNumber?: string;
    streetAddress?: string;
    city?: string;
    state?: string;
    zipCode?: string;
}
