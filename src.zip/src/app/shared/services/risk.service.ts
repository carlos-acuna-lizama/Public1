import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { RiskData } from 'src/model/riskData';
import { QueryAddress } from '../../../model/queryAddress';
import { CoverageLimits } from 'src/model/CoverageLimits';
import { DescriptionsForCharacteristics } from 'src/model/DescriptionsForCharacteristics';
import { RateData } from 'src/model/rateData';

@Injectable({
  providedIn: 'root'
})
export class RiskService {

  constructor(private http: HttpClient) {
  }

  getRiskData(queryAddress: QueryAddress): Observable<RiskData> {
    // Initialize Params Object
    const baseUrl = 'https://api-dev.alignfinancial.com/api/RiskData/Get';
    const params = new HttpParams()
      .append('streetNumber', queryAddress.streetNumber)
      .append('streetAddress', queryAddress.streetAddress)
      .append('city', queryAddress.city)
      .append('state', queryAddress.state)
      .append('zipCode', queryAddress.streetNumber);

    return this.http.get<RiskData>(baseUrl, { params });
  }

  // 10449 Peach Avenue, California City, California, EE. UU.
  getSlidersData(dwelling: number): Observable<CoverageLimits[]> {
    const baseUrl = 'https://api-dev.alignfinancial.com/api/CoverageLimits/Get';
    const params = new HttpParams().set('dwelling', String(dwelling));

    return this.http.get<CoverageLimits[]>(baseUrl, { params });
  }

  getDeductibleData(): Observable<number[]> {
    const baseUrl = 'https://api-dev.alignfinancial.com/api/Deductibles/Get';

    return this.http.get<number[]>(baseUrl);
  }

  getCharacteristicsData(): Observable<DescriptionsForCharacteristics[]> {
    const baseUrl = 'https://api-dev.alignfinancial.com/api/DescriptionsForCharacteristics/Get';

    return this.http.get<DescriptionsForCharacteristics[]>(baseUrl);
  }


  postRiskData(riskData: RiskData): Observable<RateData> {
    const baseUrl = 'https://api-dev.alignfinancial.com/api/Rate/Get';

    const objet = {
      streetAddress: riskData.streetAddress,
      city: riskData.city,
      state: riskData.state,
      zipCode: riskData.zipCode,
      yearBuilt: riskData.yearBuilt,
      squareFootage: riskData.squareFootage,
      numberOfStories: riskData.numberOfStories,
      structureType: riskData.structureType,
      structureTypeDescription: riskData.structureTypeDescription,
      constructionType: riskData.constructionType,
      constructionTypeDescription: riskData.constructionTypeDescription,
      foundationType: riskData.foundationType,
      partialCoverageADwellingLimitsFactors: riskData.partialCoverageADwellingLimitsFactors,
      retrofitting: {
        boltedToFoundation: riskData.retrofitting.boltedToFoundation,
        bracedCrippleWallsNoCrippleWalls: riskData.retrofitting.bracedCrippleWallsNoCrippleWalls
      },
      deductibleFactor: riskData.deductibleFactor,
      lossAssessmentCoverage: riskData.lossAssessmentCoverage,
      sharedLossSettlement: riskData.sharedLossSettlement,
      dwellingLimits: riskData.dwellingLimits,
      otherStructuresLimit: riskData.otherStructuresLimit,
      peronalPropertyLimit: riskData.peronalPropertyLimit,
      lossOfUseLimit: riskData.lossOfUseLimit,
      temblorData: {
        repairCost: riskData.temblorData.repairCost,
        damageEstimate: riskData.temblorData.damageEstimate,
        outofPocketCost: riskData.temblorData.outofPocketCost,
        largestEQEventMagnitude: riskData.temblorData.largestEQEventMagnitude,
        liklihoodEQEventMagnitude: riskData.temblorData.largestEQEventMagnitude
      }
    };

    return this.http.post(baseUrl, objet);
  }
}
