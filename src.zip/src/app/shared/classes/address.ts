export class Address {
  streetNumber?: string;
  streetAddress?: string;
  city?: string;
  state?: string;
  zipCode?: string;
}

/*
0: {long_name: "10449", short_name: "10449", types: Array(1)}                     streetNumber
1: {long_name: "Peach Avenue", short_name: "Peach Ave", types: Array(1)}          streetAddress
2: {long_name: "California City", short_name: "California City", types: Array(2)} city
4: {long_name: "California", short_name: "CA", types: Array(2)}                   state
6: {long_name: "93505", short_name: "93505", types: Array(1)}                     zipCode
 */

 // 10449 Peach Avenue, California City, California, EE. UU.
