export interface RiskData {
  streetNumber: string;
  streetAddress: string;
  city: string;
  state: string;
  zipCode: string;
}
