import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-earthquake',
  templateUrl: './earthquake.component.html',
  styleUrls: ['./earthquake.component.scss']
})
export class EarthquakeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
