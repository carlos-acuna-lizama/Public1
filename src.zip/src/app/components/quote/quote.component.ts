import { Component, OnInit, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { faArrowAltCircleDown, faCalendarDay } from '@fortawesome/free-solid-svg-icons';
import { RiskService } from '../../shared/services/risk.service';
import { QueryAddress } from '../../../model/queryAddress';
import { RiskData } from 'src/model/riskData';
import { } from 'googlemaps';
import { EarthQuakeEvent } from 'src/model/EarthQuakeEvent';

@Component({
  selector: 'app-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.scss']
})
export class QuoteComponent implements OnInit, AfterViewInit {
  faArrowAltCircleDown = faArrowAltCircleDown;
  calendarIcon = faCalendarDay;
  queryAddress = new QueryAddress();

  riskData: RiskData;
  newRiskData: RiskData;
  Total_Premium: number = 205.48;
  fullAddress: string = "Siempre viva 123";
  data_earthquake:EarthQuakeEvent[] = [];
  gmap_lat: number;
  gmap_lng: number;

  @ViewChild('map', { static: false }) mapElement: ElementRef;
  map: google.maps.Map;

  constructor(private riskService: RiskService) {
    this.queryAddress.streetNumber = '10449';
    this.queryAddress.streetAddress = 'Peach Avenue';
    this.queryAddress.city = 'California City';
    this.queryAddress.state = 'California';
    this.queryAddress.zipCode = '93505';
    
  }

  ngOnInit() {
    this.displayBefore();
    this.displayAfter();
  }
  
  displayBefore() {
    this.riskService.getRiskData(this.queryAddress).subscribe(
      riskData => {
        this.riskData = riskData;
        console.log(riskData);
      }, error => console.log(error)
    );
  }

  displayAfter() {
    this.riskService.getRiskData(this.queryAddress).subscribe(
      riskData => {
        this.riskData = riskData;
        console.log(riskData);
        this.riskData.dwellingLimits = 620000;

        this.riskService.postRiskData(this.riskData).subscribe(
          params => console.log(params)
        );
      }, error => console.log(error)
    );
  }

  ngAfterViewInit() {
    if (!(this.gmap_lat && this.gmap_lng)) {
      this.gmap_lat = 35.1149455;
      this.gmap_lng = -117.9417649;
    }    

    var myLatLng = new google.maps.LatLng(this.gmap_lat, this.gmap_lng); //{ lat: this.gmap_lat, lng: this.gmap_lng };
    const mapProperties = {
      center: myLatLng,
      zoom: 11,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    };

    var imageHome = {
      labelOrigin: new google.maps.Point(11, -10),
      url: 'assets/images/map-marker-icon.png',
      anchor: new google.maps.Point(0, 32),
      scaledSize: new google.maps.Size(50, 50)
    };

    this.map = new google.maps.Map(this.mapElement.nativeElement, mapProperties);

    var georssLayer = new google.maps.KmlLayer({
      url: 'https://github.com/carlos-acuna-lizama/Public1/blob/master/FeatureLayer2.kml?raw=true'
    });

    georssLayer.setMap(this.map);

    // for(let zi = 1; zi< 5 ; zi++)
    // {
    //   setTimeout(() => {
    //     this.map.setCenter(myLatLng);
    //     this.map.setZoom(4+zi);
    //   }, zi*500);
    // } 
    
    let timeFinish = 1500 * (this.data_earthquake.length +2);
    let i = 1; 
    this.data_earthquake.forEach(item => {
      setTimeout(() => {
        var temb1 = new google.maps.Marker({
          position: new google.maps.LatLng(item.latitude, item.longitude),
          map: this.map,
          draggable: false,
          animation: google.maps.Animation.BOUNCE,
          icon: this.obtainIconMarker(item.mag),
          zIndex: 2,
          label: {
            color: 'white',
            fontWeight: 'bold',
            fontSize: '20px',
            text: item.mag.toFixed(2)
          }
        });
        setTimeout(function () { temb1.setAnimation(null); }, timeFinish);

      }, i * 1500);
      i++;

    });    
    
    setTimeout(() => { 
      let strHtml = '<div class="lblMapPop d-flex justify-content-between"><div><label class="anualCost">Anual Cost</label><br><label id="lblTotalPremium">$' + (this.Total_Premium.toFixed(0) )+ '/year</label></div>' +
      '<div>&nbsp;&nbsp;<a class="btn btn-CustomPay" href="/payment">Purchase Now</a></div></div>'+
      '<div id="lblAddressMap">' + this.fullAddress + '</div>';
      var iw1 = new google.maps.InfoWindow({
        content: strHtml
      });
      var marker = new google.maps.Marker({
        position: myLatLng,
        map: this.map,
        draggable: false,
        icon: imageHome,
        title: 'Home Address',
        zIndex: 1
      });

      // var cityCircle = new google.maps.Circle({
      //   strokeColor: '#FF0000',
      //   strokeOpacity: 0.35,
      //   strokeWeight: 2,
      //   fillColor: '#FF0000',
      //   fillOpacity: 0.1,
      //   map: this.map,
      //   center: myLatLng,
      //   radius: 120701
      // });
      
      iw1.open(this.map, marker);
      google.maps.event.addListener(marker, "click", function (e) { iw1.open(this.map, this); });
      for(let zi = 1; zi< 5 ; zi++)
    {
      setTimeout(() => {
        this.map.setCenter(myLatLng);
        this.map.setZoom(4+zi);
      }, zi*500);
    } 
      
    }, timeFinish);
    //End
  } 

  obtainIconMarker(mag): google.maps.ReadonlyIcon {
    let sccal = (mag * 100) / 6;
    let rango = 1;
    if (mag > 2)
      rango = 0;
    return {
      url: 'assets/images/red-dot3.svg',
      origin: new google.maps.Point(0, 0),
      scaledSize: new google.maps.Size(sccal, sccal)
    };
  }
}
