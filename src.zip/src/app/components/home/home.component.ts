import { Component, OnInit } from '@angular/core';
import { faHome } from '@fortawesome/free-solid-svg-icons';
import { Address } from '../../shared/classes/address';

// TODO arreglar esto, TypeScript puede mejorar la inferencia del tipo de dato
declare var google;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  homeIcon = faHome;
  address: Address;
  place: string;

  constructor() { }

  ngOnInit() {
    const autocomplete = new google.maps.places.Autocomplete(document.getElementById('autocomplete'), { types: ['geocode'] });

    // tslint:disable-next-line: only-arrow-functions
    google.maps.event.addListener(autocomplete, 'place_changed', function() {
      this.place = autocomplete.getPlace();

      this.address = new Address();

      for (const component of this.place.address_components) {
        switch (component.types[0]) {
          case 'street_number': {
            this.address.streetNumber = component.long_name;
            break;
          }
          case 'route': {
            this.address.streetAddress = component.long_name;
            break;
          }
          case 'locality': {
            this.address.city = component.long_name;
            break;
          }
          case 'administrative_area_level_1': {
            this.address.state = component.long_name;
            break;
          }
          case 'postal_code': {
            this.address.zipCode = component.long_name;
            break;
          }
        }
      }

      console.log(this.address);
    });
  }
}
